__author__ = "lumiq"

from wealthcentral.utils.config_utils import (
    parse_job_arguments,
    load_env_variables,
    parse_staging_job_arguments,
    parse_raw_job_arguments
)
import os
import logging
from wealthcentral.utils.logging_utils import init_logger
from wealthcentral.jobs.staging_to_raw.staging_job import load_file_in_staging
from wealthcentral.jobs.staging_to_raw.raw_job import load_file_in_raw
from wealthcentral.utils.object_utils import RawJobArguments
from wealthcentral.utils.spark_utils import init_spark_session


if __name__ == "__main__":
    print('Starting PySpark Application')

    # Parse Job Arguments
    print('Parsing Job Arguments')

    job_arguments = parse_job_arguments()
    print('Parsed Job Arguments: env: %s, job_name: %s',
          job_arguments.env,
          job_arguments.job_name
          )

    # Load Environment Variables
    # TODO: Fix path to environment variables file and add try-catch
    print('Loading Environment Variables')
    load_env_variables(job_arguments.env)
    print('Environment Variables Loaded')

    # Load Logger
    logging_config_path = os.getenv('LOGGING_CONFIG_PATH')

    init_logger(
        config_path=logging_config_path
    )
    logger = logging.getLogger('pyspark')

    # Initialise Spark Session
    spark = init_spark_session()

    # Trigger Job Basis 'job_name' variable
    if job_arguments.job_name == 'daily_staging':
        # Load Staging Job Arguments
        staging_job_arguments = parse_staging_job_arguments()
        logger.info('Parsed Staging Job Arguments: file_recv_date: %s, file_recv_ts: %s, source_name: %s, file_name: %s, file_segment_name: %s',
                    staging_job_arguments.file_recv_date,
                    staging_job_arguments.file_recv_ts,
                    staging_job_arguments.source_name,
                    staging_job_arguments.file_name,
                    staging_job_arguments.file_segment_name
                    )

        load_file_in_staging(
            spark=spark,
            job_arguments=staging_job_arguments,
        )

    elif job_arguments.job_name == 'daily_raw':
        # Load Raw Job Arguments
        raw_job_arguments = parse_raw_job_arguments()
        logger.info(
            'Parsed Raw Job Arguments: batch_date: %s, source_name: %s, file_name: %s, file_segment_name: %s',
            raw_job_arguments.batch_date,
            raw_job_arguments.source_name,
            raw_job_arguments.file_name,
            raw_job_arguments.file_segment_name
            )

        load_file_in_raw(
            spark=spark,
            job_arguments=raw_job_arguments,
        )

    elif job_arguments.job_name == 'daily_staging_to_raw':
        # Load Staging Job Arguments
        staging_job_arguments = parse_staging_job_arguments()
        logger.info('Parsed Staging Job Arguments: file_recv_date: %s, file_recv_ts: %s, source_name: %s, file_name: %s, file_segment_name: %s',
                    staging_job_arguments.file_recv_date,
                    staging_job_arguments.file_recv_ts,
                    staging_job_arguments.source_name,
                    staging_job_arguments.file_name,
                    staging_job_arguments.file_segment_name
                    )

        batch_date, file_parameters = load_file_in_staging(
            spark=spark,
            job_arguments=staging_job_arguments,
        )

        raw_job_arguments = RawJobArguments(
            batch_date=batch_date,
            source_name=staging_job_arguments.source_name,
            file_name=staging_job_arguments.file_name,
            file_segment_name=staging_job_arguments.file_segment_name,
        )
        logger.info(
            'Raw Job Arguments: batch_date: %s, source_name: %s, file_name: %s, file_segment_name: %s',
            raw_job_arguments.batch_date,
            raw_job_arguments.source_name,
            raw_job_arguments.file_name,
            raw_job_arguments.file_segment_name
        )

        load_file_in_raw(
            spark=spark,
            job_arguments=raw_job_arguments,
            file_parameters=file_parameters
        )
