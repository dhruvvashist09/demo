import yaml
import sys
import json
from os import path
from kafka import KafkaProducer
from kubernetes import client, config
sys.path.insert(1, '/home/dhruv/Projects/Tikali/seaa/kubernetes-job')
from response_schema_pb2 import responsedata
from response_failure_pb2 import responsefailure


#producer = KafkaProducer(bootstrap_servers=['10.100.240.4:30191'],value_serializer=lambda v: json.dumps(v).encode('utf-8'))
producer = KafkaProducer(bootstrap_servers=['10.100.240.4:30191'])
JOB_NAME = "pi-%s" % sys.argv[1]
requestId = sys.argv[1]

def create_job_object():
    # Configureate Pod template container
    container = client.V1Container(
        name="pi",
        image="ubuntu",
        command=["perl", "-Mbignum=bpi", "-wle", "print bpi(2000)"])
    # Create and configurate a spec section
    template = client.V1PodTemplateSpec(
        metadata=client.V1ObjectMeta(labels={"app": "pi"}),
        spec=client.V1PodSpec(restart_policy="Never", containers=[container]))
    # Create the specification of deployment
    spec = client.V1JobSpec(
        template=template,
        backoff_limit=4)
    # Instantiate the job object
    job = client.V1Job(
        api_version="batch/v1",
        kind="Job",
        metadata=client.V1ObjectMeta(name=JOB_NAME),
        spec=spec)

    return job

def create_job(api_instance, job):
    api_response = api_instance.create_namespaced_job(
        body=job,
        namespace="demo")
    #print("Job created. status='%s'" % str(api_response.status))
    #print("Job arguments args='%s'" % sys.argv[1])


def update_job(api_instance, job):
    # Update container image
    job.spec.template.spec.containers[0].image = "perl"
    api_response = api_instance.patch_namespaced_job(name=JOB_NAME,namespace="demo",body=job)
    #print("Job updated. status='%s'" % str(api_response.status))


def delete_job(api_instance):
    api_response = api_instance.delete_namespaced_job(
        name=JOB_NAME,
        namespace="demo",
        body=client.V1DeleteOptions(
            propagation_policy='Foreground',
            grace_period_seconds=5))
    print("status='%s'" % str(api_response.status))


def main():
    # Configs can be set in Configuration class directly or using helper
    # utility. If no argument provided, the config will be loaded from
    # default location.
    config.load_kube_config()
    batch_v1 = client.BatchV1Api()
    # Create a job object with client-python API. The job we
    # created is same as the `pi-job.yaml` in the /examples folder.
    try:
        job = create_job_object()
        create_job(batch_v1, job)
        update_job(batch_v1, job)
        delete_job(batch_v1)
        #vol_dict = {'requestId': requestId, 'resultCode':'Complete','resultPaths':''+requestId+'/report.html'}
        #vol_json = json.dumps(vol_dict)
        respdata = responsedata (requestId = requestId,resultCode = 'Complete',resultPaths = ''+requestId+'/report.html')
        producer.send('dev-test', value=respdata.SerializeToString())
        producer.flush()
    except:
        print('An exception occurred')
        #vol_dict = {'requestId': requestId, 'resultCode':'Failed','Output':'Job Failed. Please check logs for more Details'}
        #vol_json = json.dumps(vol_dict)
        respdata = responsefailure (requestId = requestId,responseCode = '503',responseMessage = 'Failure', responseDescription = 'Job Failed. Please check logs for more details')
        producer.send('dev-test', value=respdata.SerializeToString())
        producer.flush()


if __name__ == '__main__':
    main()