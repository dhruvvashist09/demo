from dotenv import load_dotenv
import simplejson
import argparse
from pathlib import Path
from wealthcentral.utils.object_utils import JobArguments, StagingJobArguments, RawJobArguments, ControlTableParameters
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType


def parse_job_arguments():
    """
    Parse Cmd line args
    Return Example: Namespace(config_file_name=file_config.json)
    :return: ArgumentParser Namespace
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", help="specify env: dev, unit, intg, accp, prod")
    parser.add_argument("--job_name", help="specify job name")
    parser.add_argument("--file_recv_date", help="specify date (yyyyMMdd) on which file was received", required=False)
    parser.add_argument("--file_recv_ts",
                        help="specify timestamp string (hh:mm) in 24 hour format on which file was received", required=False)
    parser.add_argument("--source_name", help="specify source system name", required=False)
    parser.add_argument("--file_name", help="specify file name", required=False)
    parser.add_argument("--file_segment_name", help="specify file segment name", required=False)
    args = parser.parse_args()
    parsed_args = JobArguments(
        env=args.env,
        job_name=args.job_name,
    )
    return parsed_args


def load_env_variables(env):
    file_path = f"wealthcentral/conf/.env.{env}"
    if env != 'dev':
        file_path = '/databricks/python/lib/python3.8/site-packages/' + file_path

    env_file = Path(file_path)
    if env_file.is_file():
        load_dotenv(env_file)
        return True
    else:
        return False


def parse_staging_job_arguments():
    """
    Parse Cmd line args
    Return Example: Namespace(config_file_name=file_config.json)
    :return: ArgumentParser Namespace
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", help="specify env: dev, unit, intg, accp, prod", required=False)
    parser.add_argument("--job_name", help="specify job name", required=False)
    parser.add_argument("--file_recv_date", help="specify date (yyyyMMdd) on which file was received")
    parser.add_argument("--file_recv_ts",
                        help="specify timestamp string (hh:mm) in 24 hour format on which file was received")
    parser.add_argument("--source_name", help="specify source system name")
    parser.add_argument("--file_name", help="specify file name")
    parser.add_argument("--file_segment_name", help="specify file segment name")
    args = parser.parse_args()
    parsed_args = StagingJobArguments(
        file_recv_date=args.file_recv_date,
        file_recv_ts=args.file_recv_ts,
        source_name=args.source_name,
        file_name=args.file_name,
        file_segment_name=args.file_segment_name,
    )
    return parsed_args


def parse_raw_job_arguments():
    """
    Parse Cmd line args
    Return Example: Namespace(config_file_name=file_config.json)
    :return: ArgumentParser Namespace
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_date", help="specify batch date (yyyyMMdd) for which process needs to be executed")
    parser.add_argument("--source_name", help="specify source system name")
    parser.add_argument("--file_name", help="specify file name")
    parser.add_argument("--file_segment_name", help="specify file segment name")
    args = parser.parse_args()
    parsed_args = RawJobArguments(
        batch_date=args.batch_date,
        source_name=args.source_name,
        file_name=args.file_name,
        file_segment_name=args.file_segment_name,
    )
    return parsed_args


def load_json_file(file_path):
    """
    Given the config file name, it reads the config file and returns it in the form of JSON dict
    :return: config in the form of dictionary
    """
    with open(file_path) as config_file:
        try:
            return simplejson.load(config_file)
        except simplejson.errors.JSONDecodeError as error:
            raise simplejson.errors.JSONDecodeError(
                f"Issue with the Job Config: {file_path} {error}"
            )


def add_control_table_entry(spark: SparkSession, control_table_parameters: ControlTableParameters):
    # Define the schema of the DataFrame
    schema = StructType([
        StructField("source_name", StringType(), True),
        StructField("file_name", StringType(), True),
        StructField("file_segment_name", StringType(), True),
        StructField("batch_date", StringType(), True),
        StructField("table_name", StringType(), True),
        StructField("etl_start_datetime", StringType(), True),
        StructField("etl_end_datetime", StringType(), True),
        StructField("record_count", IntegerType(), True),
        StructField("status", StringType(), True),
        StructField("created_by", StringType(), True)
    ])

    # Create a PySpark DataFrame with the schema
    data = [(control_table_parameters.source_name,
             control_table_parameters.file_name,
             control_table_parameters.file_segment_name,
             control_table_parameters.batch_date,
             control_table_parameters.table_name,
             control_table_parameters.etl_start_datetime,
             control_table_parameters.etl_end_datetime,
             control_table_parameters.record_count,
             control_table_parameters.status,
             control_table_parameters.created_by)]

    df = spark.createDataFrame(data, schema=schema)

    return df
