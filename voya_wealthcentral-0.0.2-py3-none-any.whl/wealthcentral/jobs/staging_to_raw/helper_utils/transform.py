__author__ = "lumiq"
"""
Description : Python code to execute raw layer processing through delta tables created in Staging layer
"""

from pyspark.sql.functions import *
from pyspark.sql.window import Window
from delta.tables import *
from pytz import timezone
from datetime import date, timedelta, datetime
import logging, sys, traceback, calendar, time


def __init__(self):
    return

def data_cleaning(spark, filename, segment, staging_df, source_system, rawPath, table, load_type, user, startTime, pkList):
    try:

        # # Instantiating control and path variables
        # status = 'Fail'
        # recordCount = 0
        # runType = 'Raw'
        # path = rawPath + source_system
        #
        # const_df = read_constant_file()
        #
        # schema_file_path = '/artifacts/'
        #
        # if 'Transaction_VNQ_WC.txt' in filename:
        #     schema_file_name = 'Transaction_VNQ_WC.txt_schema.json'
        #     if len(filename) is not 22:
        #         table = table + '_historical'
        #
        # elif 'Participant_Fund_VNQ_WC.txt' in filename:
        #     schema_file_name = 'Participant_Fund_VNQ_WC.txt_schema.json'
        #     if len(filename) is not 27:
        #         table = table + '_historical'
        #
        # else:
        #     schema_file_name = '{}_schema.json'.format(filename.split('__')[0])
        #
        # schema_df = spark.read.json(schema_file_name, multiLine=True)
        #
        # primary_keys = pkList
        #
        # # Adding raw_run_date column to the dataframe to persist the date of execution into the table
        # # TODO: Column name to be confirmed with Ashish along with Format
        # df = staging_df.withColumn('etl_run_date', to_date(lit(get_current_date()), "yyyy-MM-dd"))

        # # TODO: Tablename to replaced by Filename
        # if primary_keys is not [] and table not in ('Transaction_VNQ_WC_txt', 'Transaction_VNQ_WC_txt_historical'):
        #     df = stub_dedupe_keys(primary_keys, df, table)

        # TODO: Tablename to replaced by Filename
        # if table.startswith('super_omni') or table.startswith('exn_'):
        #     if 'plan_id' in df.columns or 'plan_number' in df.columns:
        #         df = filter_plan_number(df=df, table=table)
        #
        # if 'SEQHIST' in filename or 'exn.xxewre01.xxewrtrxh' in filename:
        #     df = parse_txn_data(txn_df=df)
        #
        # if 'ssn.output' in filename or 'SSN.OUTPUT' in filename:
        #     df = replace_client(df)
        #
        # if 'exn.xxewre01.xxewrppl.JB' in filename or 'exn.xxewre01.xxewrppl.NG' in filename:
        #     df = replace_loan_type(df)
        #
        # if table is 'exn_xxewre01_xxewrpfd_ng':
        #     df = df.withColumn(
        #         'fund_code',
        #         when(
        #             df.fund_iv == '90',
        #             'LN90'
        #         )
        #         .when(
        #             df.fund_iv == '91',
        #             'LN91'
        #         )
        #         .otherwise(
        #             df.fund_code
        #         )
        #     )
        #
        # if table is 'exn_xxewre01_xxewrpfd_jb':
        #     df = df.withColumn(
        #         'price_id',
        #         when(
        #             df.fund_iv == '90',
        #             'LN90'
        #         )
        #         .when(
        #             df.fund_iv == '91',
        #             'LN91'
        #         )
        #         .otherwise(
        #             df.price_id
        #         )
        #     )

        truncStatus, upsertStatus = 'Fail', 'Fail' #?

        if load_type is 'T':
            batch_date = df.select(max('batch_date').alias('max_batch_date')).first()['max_batch_date']

            truncStatus, runType = truncate_load(df=df, tableName=table, path=path)
            if truncStatus is 'Pass':
                status = 'Pass'

        elif load_type is 'U':
            upsertStatus, runType = upsert(df, tableName=table, pkList=pkList, path=path)
            if upsertStatus is 'Pass':
                status = 'Pass'

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        raw_control_table(df, table, status, runType, user, filename, )

def substitute_null_pkeys(df, pKeys):
    for key in pKeys:  # ? All primary keys to be filled with -9999?
        if 'date' in key or '_dt' in key:
            default = '1000-01-01'
        else:
            default = '-9999'

        df = df.fillna(default, subset=[key])
        df = df.withColumn(
            key,
            when(
                col(key) == '',
                default
            )
            .otherwise(
                col(key)
            )
        )

        if default is not '-9999' and ('date' in key or '_dt' in key):
            df = df.withColumn(key, to_date(col(key)))

    return df

# TODO: To be corrected by Addy
# Replace None values in primary keys with default values and perform de duplication on 'df' using primary keys.
# Persist duplicate records in a separate '_rejected' table
def remove_duplicates(spark, pKeys, df, table):
    try:
        batchWindow = Window.partitionBy(pKeys).orderBy(col('batchDate'))

        logging.info("Removing duplicate primary key records from the dataframe 'df'")
        dupe_df = df.withColumn('rn', row_number().over(batchWindow)).filter('rn > 1').drop('rn')
        rejected_table = '{}_rejected'.format(table)
        table_run_date = spark.sql(
            "SELECT max(RawFileRunDate) as maxDate FROM newr_raw.raw_control_table WHERE filename = '{}'".format(
                table)).first()['maxDate']

        if table_run_date is get_current_date():
            dupe_df.write.mode('append').saveAsTable('newr_raw.{}'.format(rejected_table))

        df = df.drop_duplicates(pKeys)
        df = df.drop('rank')

        return df

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())
    except AttributeError:
        logging.error(traceback.format_exc())
    except NameError:
        logging.error(traceback.format_exc())
    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


# May not be needed
def primary_keys():
    return

# TODO: To be corrected by Addy
# Reject records from dataframe with unwanted plan_number values
def filter_plan_number(df, table):
    try:
        if 'plan_id' in df.columns:
            column = 'plan_id'
        elif 'plan_number' in df.columns:
            column = 'plan_number'

        reject_df = df.where(df[column].between('000001', '000040'))
        reject_df.write.mode('append').saveAsTable('{}_rejected'.format(table))

        df = df.where(~df[column].between('000001', '000040'))
        return df

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())
    except AttributeError:
        logging.error(traceback.format_exc())
    except NameError:
        logging.error(traceback.format_exc())
    except Exception as e:
        logging.error(traceback.format_exc())
    finally:
        pass


# Parsing the trasactions file - named daily_seqhist
def parse_txn_data(txn_df):
    amounts_dict = {
        'cash': [13, 2],
        'shares': [13, 4],
        'uninvested_cash': [13, 2],
        'share_cost': [13, 2],
        'other_cash': [13, 2],
        'share_price': [13, 6],
        'currency_value': [13, 2],
        'xr_rate': [11, 6],
        'net_currency_value': [13, 2]
    }

    for key, val in amounts_dict.items():
        txn_df = handle_amounts(txn_df, key, val[0], val[1])

    txn_df = replace_null(txn_df)

    return txn_df


# Replace empty rev_code values with default values
def replace_null(data_frame):
    data_frame = data_frame.fillna('0', subset=['rev_code'])

    data_frame = data_frame.withColumn(
        'rev_code',
        when(
            col('rev_code') == '',
            '0'
        )
        .otherwise(
            col('rev_code')
        )
    )

    return data_frame


# Update dataframe containing transactions data by replacing representative characters with respective digits in Amount fields
# TODO: To be corrected by Addy (Priority - Low)
def handle_amounts(df, column_name, precision, scale):
    try:

        diff = precision - scale
        df = df.withColumn(column_name, concat(substring(column_name, 1, diff), lit('.'),
                                               substring(column_name, diff + 1, precision)))

        df = df.withColumn(column_name,
                           when(
                               col(column_name).endswith('p'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'p', '0')
                               )
                           )
                           .when(
                               col(column_name).endswith('q'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'q', '1')
                               )
                           )
                           .when(
                               col(column_name).endswith('r'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'r', '2')
                               )
                           )
                           .when(
                               col(column_name).endswith('s'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 's', '3')
                               )
                           )
                           .when(
                               col(column_name).endswith('t'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 't', '4')
                               )
                           )
                           .when(
                               col(column_name).endswith('u'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'u', '5')
                               )
                           )
                           .when(
                               col(column_name).endswith('v'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'v', '6')
                               )
                           )
                           .when(
                               col(column_name).endswith('w'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'w', '7')
                               )
                           )
                           .when(
                               col(column_name).endswith('x'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'x', '8')
                               )
                           )
                           .when(
                               col(column_name).endswith('y'),
                               concat(
                                   lit('-'),
                                   regexp_replace(col(column_name), 'y', '9')
                               )
                           )
                           )

        return df

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())
    except AttributeError:
        logging.error(traceback.format_exc())
    except NameError:
        logging.error(traceback.format_exc())
    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


# Replace empty client_id values with default values
def replace_client(df):
    df = df.fillna(value='NG', subset=['client_id'])
    df = df.withColumn(
        'client_id',
        when(
            col('client_id') == '',
            'NG'
        )
        .otherwise(
            col('client_id')
        )
    )

    return df


# Replace empty loan_type values with default values
def replace_loan_type(df):
    df = df.fillna(value='G', subset=['loan_type_id'])

    df = df.withColumn(
        'loan_type_id',
        when(
            col('loan_type_id') == '',
            'G'
        )
        .otherwise(
            col('loan_type_id')
        )
    )

    return df


# Truncate and Load implementation for full files
def truncate_load(spark, df, tableName, path):
    ## Instantiating variables
    # recordCount = 0
    status = 'Fail'
    runType = 'Raw'

    try:

        # Adding hash key column to the source dataframe
        df = df.select('*').withColumn('raw_hash_key', hash('*'))

        # Check if target table exists
        if spark._jsparkSession.catalog().tableExists("{}.{}".format("newr_raw", tableName)):

            # If target table exists, truncate it
            spark.sql('TRUNCATE TABLE {}.{}'.format("newr_raw", tableName))

            # Load source table into target table
            df.repartition(1, 'batch_date').write.partitionBy('batch_date').saveAsTable(
                '{}.{}'.format('newr_raw', tableName), format='delta', mode='append',
                path='{}/{}'.format(path, tableName))

            # Update control variables
            status = 'Pass'
            runType = 'Raw with SSN'

        else:
            # If target table does not exist, create it
            df.repartition(1, 'batch_date').write.partitionBy('batch_date').saveAsTable(
                '{}.{}'.format('newr_raw', tableName), format='delta', mode='overwrite',
                path='{}/{}'.format(path, tableName))

            # Update control variable
            status = 'Pass'

        return status, runType

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    # Persist control variable to control table for job tracking
    finally:
        pass

        # Get current execution date
        runDate = get_current_date()

        # Get Execution end time
        endTime = get_current_time()

        # # Write to control table for raw layer
        # raw_control_table(tableName, runDate, status, user, fileName, segmentList, loadType, runType, startTime, endTime, recordCount)

        # return status, runType


# Upsert implementation for incremental files - adds only, action code, etc. files
def upsert(spark, df, tableName, pkList, path):
    # Instantiating variables
    status = 'Fail'
    runType = 'Raw'

    try:

        if spark._jsparkSession.catalog().tableExists('{}.{}'.format('newr_raw', tableName)):
            logicStr, value = create_delta_merge_logic(primaryKeys=pkList)

            deltaTable = DeltaTable.forName(spark, '{}.{}'.format('newr_raw', tableName))

            value['segment'] = col('newData.segment')
            value['filename'] = col('newData.filename')
            value['raw_run_date'] = col('newData.raw_run_date')
            value['batch_date'] = col('newData.batch_date')

            if tableName in ('Transaction_VNQ_WC_txt', 'Transaction_VNQ_WC_txt_historical'):
                df_delta, value = nq_transaction_upsert(df, tableName=tableName, value=value)

                # Perform delta merge on NQ transaction tables
                deltaTable.alias('oldData').merge(df_delta.alias('newData'), logicStr).whenMatchedUpdate(
                    set=value).whenNotMatchedInsert(values=value).execute()

                if 'participant_id' in df_delta.columns: #?
                    # ssn_change(tableName, path, getSchemaAndType)
                    runType = ssn_change_merge_handling(tableName=tableName, operation='change')
                    # runType = ssn_merge(tableName, path, getSchemaAndType)
                    runType = ssn_change_merge_handling(tableName, operation='merge')
                status = 'Pass'
            else:

                if 'seq_oper_code' in df.columns:
                    df = delete_action_code_handling(df)

                    # Perform delta merge
                    deltaTable.alias('oldData').merge(df.alias('newData'), logicStr).whenMatchedDelete(
                        condition="newData.seq_oper_code = 'D'").whenMatchedUpdate(set=value).whenNotMatchedInsert(
                        values=value).execute()
                else:
                    deltaTable.alias('oldData').merge(df_delta.alias('newData'), logicStr).whenMatchedUpdate(
                        set=value).whenNotMatchedInsert(values=value).execute()

                if 'participant_id' in df.columns:
                    # ssn_change(tableName, path, getSchemaAndType)
                    runType = ssn_change_merge_handling(tableName, operation='change')
                    # runType = ssn_merge(tableName, path, getSchemaAndType)
                    runType = ssn_change_merge_handling(tableName, operation='merge')
                status = 'Pass'
        else:
            if tableName in ('Transaction_VNQ_WC_txt', 'Transaction_VNQ_WC_txt_historical'):
                window = Window().orderBy('plan_number')
                df = df.withColumn('newr_nqtxn_key', row_number().over(window))

            # Persist dataframe 'df' as delta table
            df.repartition(1, 'batch_date').write.partitionBy('batch_date').saveAsTable(
                '{}.{}'.format('newr_raw', tableName), format='delta', mode='overwrite',
                path='{}/{}'.format(path, tableName))

            if 'participant_id' in df.columns:
                # ssn_change(tableName, path, getSchemaAndType)
                runType = ssn_change_merge_handling(tableName, operation='change')
                # runType = ssn_merge(tableName, path, getSchemaAndType)
                runType = ssn_change_merge_handling(tableName, operation='merge')
            status = 'Pass'

        return status, runType

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    # Persist control variable to control table for job tracking
    finally:
        pass
        # Get current execution date
        runDate = get_current_date()

        # Get Execution end time
        endTime = get_current_time()

        # # Write to control table for raw layer
        # raw_control_table(tableName, runDate, status, user, fileName, segmentList, loadType, runType, startTime, endTime, recordCount)
        # return status, runType


# Create logic string for delta merge in Upsert method
def create_delta_merge_logic(primaryKeys):
    try:
        logicStr = ' and '.join('oldData.{} = newData.{}'.format(pkColumn, pkColumn) for pkColumn in primaryKeys)
        columnsDict = {}

        for pkColumn in primaryKeys:
            columnsDict[pkColumn] = col('newData.{}'.format(pkColumn))

        return logicStr, columnsDict

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


# Extra handling in Upsert logic for NQ Tables
def nq_transaction_upsert(spark, df, table, value):
    try:

        pKeys = ['plan_number', 'participant_id', 'fund_id', 'source_id', 'transaction_type_code', 'transaction_date']

        nq_df = spark.sql('select * from {}.{}'.format('newr_raw', table))
        max_row_num = nq_df.select(max(nq_df.newr_nqtxn_key)).first()['max(newr_nqtxn_key)']

        delta_df = df.join(nq_df, [df[column] == nq_df[column] for column in pKeys], 'leftanti')

        window = Window().orderBy('plan_number')
        delta_df = delta_df.withColumn('newr_nqtxn_key', row_number().over(window) + max_row_num)

        value['newr_nqtxn_key'] = col('newrData.newr_nqtxn_key')

        return delta_df, value


    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


# Handling of 'D' Action Code for delete records in Transactions' files - 'exn....trxh' and 'super_omni_newr_daily'
def delete_action_code_handling(spark, df):
    try:
        delete_df = df.filter(df.seq_oper_code == 'D')
        curr_date = get_current_date()
        max_run_date = spark.sql(
            "SELECT max(rawFileRunDate) as maxDate from newr_raw.raw_control_table where Status ='Pass' and fileName = 'txn'").first()[
            'maxDate']

        if max_run_date == curr_date:
            delete_df.write.mode('append').saveAsTable('txn_temp')
        else:
            delete_df.write.mode('overwrite').saveAsTable('txn_temp')

        return df

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


# SSN Change Merge Logic Implementation
def ssn_change_merge_handling(spark, table, operation):
    runType = 'Raw'
    jb, ng = False, False

    today_date = get_current_date()

    try:
        ssn_jb_count = spark.sql(
            "SELECT count(*) as count FROM newr_raw.raw_control_table where filename = 'ssn_output_jb' and Status='Pass' and RawFileRunDate = '{}'".format(
                today_date)).first()['count']

        ssn_ng_count = spark.sql(
            "SELECT count(*) as count FROM newr_raw.raw_control_table where filename = 'ssn_output_ng' and Status='Pass' and RawFileRunDate = '{}'".format(
                today_date)).first()['count']

        if ssn_jb_count > 0 or ssn_ng_count > 0:

            if ssn_jb_count is not 0:
                df_jb = spark.sql('SELECT * FROM newr_raw.ssn_output_jb')
                jb = True

            if ssn_ng_count is not 0:
                df_ng = spark.sql('SELECT * FROM newr_raw.ssn_output_ng')
                ng = True

            if jb is True and ng is True:
                df = df_jb.union(df_ng)

            elif jb is False and ng is True:
                df = df_ng

            elif ng is False and jb is True:
                df = df_jb

            if operation is 'change':
                df = df.filter(df.admin_tran_conde == '850')
            elif operation is 'merge':
                df = df.filter(df.admin_tran_conde == '851')
            else:
                return 'SSN ChangeMerge Failed'

            delta_table = DeltaTable.forName(spark, '{}.{}'.format('newr_raw', table))

            if table in ('exn_xxadahst_xxadhdbx_jb', 'exn_xxadahst_xxadhdbx_ng', 'exn_xxadahst_xxadhdrx_jb',
                         'exn_xxadahst_xxadhdrx_ng'):
                delta_table.alias('oldData').merge(
                    df.alias('newData'),
                    'oldData.participant_id = newData.old_participant_id'
                ).whenMatchedUpdate(
                    set={'participant_id': 'newData.new_participant_id'}
                ).execute()
            else:
                delta_table.alias('oldData').merge(
                    df.alias('newData'),
                    'oldData.participant_id = newData.old_participant_id'
                ).whenMatchedDelete().execute()

            runType = 'Raw with SSN'

        return runType

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


def raw_control_table():
    try:
        pass

    # Handle exceptional cases
    except ValueError:
        logging.error(traceback.format_exc())

    except AttributeError:
        logging.error(traceback.format_exc())

    except NameError:
        logging.error(traceback.format_exc())

    except Exception as e:
        logging.error(traceback.format_exc())

    finally:
        pass


####################### Miscellaneous
# Utility method to get current date value in string format
def get_batch_date(df, runDate):
    column_list = ['dss_cycle_date', 'source_cycle_date', 'cycle_date', 'prx_cycle_date', 'Run_date', 'valuation_date']

# TODO: Check runDate format. If yyyy-MM-dd then continue else modify runDate
    for column in column_list:
        if column in df.columns:
            batchDate = int(df.select(max(col(column)).alias('source_cycle_date')).first()['source_cycle_date']).replace('-','')
        else:
            batchDate = runDate.replace('-','')
    return


def get_current_date():
    return str(datetime.now(timezone('America/New_York'))).split(' ')[0]


# Utility method to get current time value in string format
def get_current_time():
    return str(datetime.now(timezone('America/New_York'))).split(" ")[1].split("-")[0]


def change_string_to_date():
    return


def get_schema_and_type(self, path) -> str:
    return
