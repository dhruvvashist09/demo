__author__ = "lumiq"

# data_utils.py: Contains utility functions for
# reading data from source file
# manipulation of data
# data transformation
# writing final data


from pyspark.sql import SparkSession
from wealthcentral.jobs.staging_to_raw.helper_utils.objects_utils import FileParameters, FileToSchemaMapper
import os
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from datetime import time
from wealthcentral.utils.object_utils import StagingJobArguments
from datetime import datetime
from pytz import timezone


def get_current_datetime():
    return datetime.now(timezone('America/New_York')).strftime("%Y-%m-%d %H:%M:%S")


def read_data_from_file(spark: SparkSession, job_arguments: StagingJobArguments, file_parameters: FileParameters):
    """
    For a source type and source config, it reads the data and
    returns it in the form of spark dataframe
    :param spark: spark session
    :param source_type: string signifying the source type
    :param source_config: dictionary with all the necessary information about a source data
    :return: spark dataframe
    """
    if file_parameters.file_type == 'delimited':
        df = read_delimited_file(
            spark=spark,
            job_arguments=job_arguments,
            file_parameters=file_parameters
        )
    elif file_parameters.file_type == 'fixed_width':
        df = read_fixed_width_file(
            spark=spark,
            job_arguments=job_arguments,
            file_parameters=file_parameters
        )
    return df


def read_delimited_file(spark: SparkSession, job_arguments: StagingJobArguments, file_parameters: FileParameters):
    delimiter_mapper = {
      "psv": "|",
      "csv": ","
    }
    if file_parameters.file_header_flag:
        options = {
          "header": "true",
          "inferSchema": "false",
          "delimiter": delimiter_mapper.get(file_parameters.file_format)
        }
    else:
        options = {
            "header": "false",
            "inferSchema": "false",
            "delimiter": delimiter_mapper.get(file_parameters.file_format)
        }

    schema = FileToSchemaMapper.get(file_parameters.file_name)

    source_load_df = spark.read\
        .options(**options)\
        .schema(schema)\
        .csv(f"{os.getenv('STAGING_INPUT_PATH')}/{job_arguments.file_recv_date}/{job_arguments.source_name}/{job_arguments.file_name}/{job_arguments.file_segment_name}")

    # Convert column names to lowercase and trim
    source_load_df = source_load_df.select([trim(col(c)).alias(c.lower()) for c in source_load_df.columns])

    return source_load_df


def read_fixed_width_file(spark: SparkSession, job_arguments: StagingJobArguments, file_parameters: FileParameters):
    options = {
      "header": "false",
      "inferSchema": "false",
      "encoding": 'UTF-16'
    }
    schema = FileToSchemaMapper.get(file_parameters.file_name)

    source_load_df = spark.read\
        .options(**options)\
        .text(f"{os.getenv('STAGING_INPUT_PATH')}/{job_arguments.file_recv_date}/{job_arguments.source_name}/{job_arguments.file_name}/{job_arguments.file_segment_name}")

    # Handle null characters and extra characters in df
    null_char = u'\x00\x00'
    source_load_df = source_load_df.select(*(regexp_replace(col(c), null_char, ' ').alias(c) for c in source_load_df.columns))
    source_load_df = source_load_df.filter(~ col('value').startswith("-- "))

    for column in schema:
      column_info = schema[column]
      start_pos = column_info["start"]
      end_pos = column_info["end"]
      column_type = column_info["type"]
      column_nullable = column_info["nullable"]

      source_load_df = source_load_df\
        .withColumn(column, trim(substring(source_load_df["value"], start_pos, end_pos - start_pos + 1).cast(column_type)))

    # Convert Columns to lowercase
    source_load_df = source_load_df.select([col(c).alias(c.lower()) for c in source_load_df.columns])
    source_load_df = source_load_df.drop('value')

    return source_load_df


def add_col_batch_date(df, file_recv_date, file_recv_ts):
    # If column present in batch_date_column_list
    #      file_recv_date = batch_date_column and file_recv_ts between (18:59) and (23:59) then batch_date_column
    #      file_recv_date = batch_date_column and file_recv_ts between (00:00) and (9:00) then batch_date_column - 1
    #      file_recv_date > batch_date_column and then batch_date_column
    # If column not present in batch_date_column_list
    #      file_recv_ts between (18:59) and (23:59) then file_recv_date
    #      file_recv_ts between (00:00) and (9:00) then file_recv_date - 1

    batch_date_col_found = False

    #TODO: check for 'dss_cycle_date' and 'cycle_date'
    batch_date_column_list = ['dss_cycle_date', 'source_cycle_date', 'cycle_date', 'prx_cycle_date', 'run_date', 'valuation_date', 'as_of_date']
    for batch_date_column in batch_date_column_list:
        if batch_date_column in df.columns:
            df = df.withColumn("batch_date",
                               when(
                                   (to_date(col(batch_date_column), "yyyyMMdd") == to_date(lit(file_recv_date), "yyyyMMdd")) and
                                   (time(hour=18, minute=59).strftime('%H:%M') <= file_recv_ts <= time(hour=23, minute=59).strftime('%H:%M'))
                                   , (to_date(col(batch_date_column), "yyyyMMdd").cast(StringType()))
                               ).when(
                                   (to_date(col(batch_date_column), "yyyyMMdd") == to_date(lit(file_recv_date), "yyyyMMdd")) and
                                   (time(hour=0, minute=0).strftime('%H:%M') <= file_recv_ts <= time(hour=9, minute=0).strftime('%H:%M'))
                                   , (date_sub(to_date(col(batch_date_column), "yyyyMMdd"), 1).cast(StringType()))
                               ).when(
                                   (to_date(col(batch_date_column), "yyyyMMdd") < (to_date(lit(file_recv_date), "yyyyMMdd"))
                                   , (to_date(col(batch_date_column), "yyyyMMdd").cast(StringType()))
                               )).otherwise(
                                   lit(None)
                               )
                               )
            batch_date_col_found = True
            break


    if not batch_date_col_found:
        df = df.withColumn("batch_date",
                           when(
                               time(hour=18, minute=59).strftime('%H:%M') <= file_recv_ts <= time(hour=23, minute=59).strftime('%H:%M')
                               , to_date(lit(file_recv_date), "yyyyMMdd").cast(StringType())
                           ).when(
                               time(hour=0, minute=0).strftime('%H:%M') <= file_recv_ts <= time(hour=9, minute=0).strftime('%H:%M')
                               , date_sub(to_date(lit(file_recv_date), "yyyyMMdd"), 1).cast(StringType())
                           ).otherwise(
                               lit(None)
                           )
                           )

    return df


def add_col_file_segment(df, value):
    return df.withColumn("file_segment", lit(value))


def get_distinct_batch_date(df):
    return df.select(col("batch_date")).distinct().cast(StringType()).rdd.map(lambda row: row[0]).collect()


def get_record_count(df):
    return df.count


def add_unique_key(df):
    # Get the max value of the column and convert it to a string
    max_value = df.agg(max(col('batch_date'))).collect()[0][0]

    prefix = str(max_value) + "_"

    # Define a window specification for the row number
    window_spec = Window.orderBy('plan_number')

    # Add the row number with prefix to the DataFrame
    df_with_unique_key = df\
        .withColumn("row_number", row_number().over(window_spec)) \
        .withColumn("newr_nqtxn_key", concat(lit(prefix), col("row_number").cast("string")))\
        .drop("row_number")

    return df_with_unique_key


def identify_duplicates(df, partition_key):
    """
    Drops duplicates over the specified partition key and keeps only the first occurrence of each duplicate.
    Parameters:
        df (DataFrame): The DataFrame to drop duplicates from.
        partition_key (list): A list of column names to partition by.
    Returns:
        DataFrame: The input DataFrame with duplicates over the partition key dropped.
    """
    # Check if source_cycle_date column available. Else use etl_run_date column
    order_key = 'batch_date'

    # Define the window specification
    window_spec = Window.partitionBy(partition_key).orderBy(order_key)

    # Add a row number to each partition
    df = df.withColumn("row_number", row_number().over(window_spec))

    # Flag the first occurrence of each duplicate for dropping
    df = df\
        .withColumn("to_drop", when(col("row_number") == 1, lit(False)).otherwise(lit(True)))\
        .withColumn("drop_record_remarks", when(col("row_number") == 1, lit(None)).otherwise(lit("duplicate record")))\
        .drop('row_number')

    return df


def identify_invalidate_plan_number(df):
    invalid_plan_id_lb = '000001'
    invalid_plan_id_ub = '000040'

    if 'plan_id' in df.columns:
        plan_column_name = 'plan_id'
    elif 'plan_number' in df.columns:
        plan_column_name = 'plan_number'
    else:
        plan_column_name = None

    if plan_column_name is not None:
        df = df \
            .withColumn("to_drop", when(col(plan_column_name).between(invalid_plan_id_lb, invalid_plan_id_ub), coalesce(lit(True), col("to_drop"))).otherwise(col("to_drop"))) \
            .withColumn("drop_record_remarks", when(col(plan_column_name).between(invalid_plan_id_lb, invalid_plan_id_ub), coalesce(lit("invalid plan id"), col("drop_record_remarks"))).otherwise(col("drop_record_remarks")))

    return df


# Update dataframe containing transactions data by replacing representative characters with respective digits in Amount fields
def handle_amounts(df, column_name, precision, scale):
    diff = precision - scale
    df = df.withColumn(column_name, concat(substring(column_name, 1, diff), lit('.'),
                                           substring(column_name, diff + 1, precision)))

    df = df.withColumn(column_name,
                       when(
                           col(column_name).endswith('p'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'p', '0')
                           )
                       )
                       .when(
                           col(column_name).endswith('q'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'q', '1')
                           )
                       )
                       .when(
                           col(column_name).endswith('r'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'r', '2')
                           )
                       )
                       .when(
                           col(column_name).endswith('s'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 's', '3')
                           )
                       )
                       .when(
                           col(column_name).endswith('t'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 't', '4')
                           )
                       )
                       .when(
                           col(column_name).endswith('u'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'u', '5')
                           )
                       )
                       .when(
                           col(column_name).endswith('v'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'v', '6')
                           )
                       )
                       .when(
                           col(column_name).endswith('w'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'w', '7')
                           )
                       )
                       .when(
                           col(column_name).endswith('x'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'x', '8')
                           )
                       )
                       .when(
                           col(column_name).endswith('y'),
                           concat(
                               lit('-'),
                               regexp_replace(col(column_name), 'y', '9')
                           )
                       )
                       )

    return df


# Replace empty rev_code values with default values
def replace_null(df):
    df = df.fillna('0', subset=['rev_code'])

    df = df.withColumn(
        'rev_code',
        when(
            col('rev_code') == '',
            '0'
        )
        .otherwise(
            col('rev_code')
        )
    )

    return df


def parse_txn_data(df):
    amounts_dict = {
        'cash': [13, 2],
        'shares': [13, 4],
        'uninvested_cash': [13, 2],
        'share_cost': [13, 2],
        'other_cash': [13, 2],
        'share_price': [13, 6],
        'currency_value': [13, 2],
        'xr_rate': [11, 6],
        'net_currency_value': [13, 2]
    }

    for key, val in amounts_dict.items():
        df = handle_amounts(df, key, val[0], val[1])

    df = replace_null(df)

    return df


# Replace empty client_id values with default values
def replace_client(df):
    df = df.fillna(value='NG', subset=['client_id'])
    df = df.withColumn(
        'client_id',
        when(
            col('client_id') == '',
            'NG'
        )
        .otherwise(
            col('client_id')
        )
    )

    return df


# Replace empty loan_type values with default values
def replace_loan_type(df):
    df = df.fillna(value='G', subset=['loan_type_id'])

    df = df.withColumn(
        'loan_type_id',
        when(
            col('loan_type_id') == '',
            'G'
        )
        .otherwise(
            col('loan_type_id')
        )
    )

    return df


def change_fund_code(df):
    df = df.withColumn(
        'fund_code',
        when(
            df.fund_iv == '90',
            'LN90'
        )
        .when(
            df.fund_iv == '91',
            'LN91'
        )
        .otherwise(
            df.fund_code
        )
    )

    return df


def change_price_id(df):
    df = df.withColumn(
        'price_id',
        when(
            df.fund_iv == '90',
            'LN90'
        )
        .when(
            df.fund_iv == '91',
            'LN91'
        )
        .otherwise(
            df.price_id
        )
    )

    return df


def filter_rejected_df(df):
    return df\
        .filter(col("to_drop") == True)


def filter_valid_df(df):
    return df\
        .filter(col("to_drop") == False)\
        .drop("to_drop", "drop_record_remarks")


def generate_merge_condition_for_delta_in_raw(merge_keys, target_alias_keyword="target", source_alias_keyword="source"):
    # target is delta table and source is load DF
    merge_condition = ' and '.join('{}.{} = {}.{}'.format(target_alias_keyword, pkColumn, source_alias_keyword, pkColumn) for pkColumn in merge_keys)
    return merge_condition


def generate_update_condition_for_delta_in_raw(col_list, target_alias_keyword="target", source_alias_keyword="source"):
    """
    Creates a target dictionary with the specified structure.

    Parameters:
        col_list (list): A list of column names.

    Returns:
        dict: A dictionary with the specified structure.
    """
    # target is delta table and source is load DF
    dict = {}
    for col_name in col_list:
        dict[col_name] = f"{source_alias_keyword}.{col_name}"
    return dict


def generate_insert_condition_for_delta_in_raw(col_list, target_alias_keyword="target", source_alias_keyword="source"):
    """
    Creates a target dictionary with the specified structure.

    Parameters:
        col_list (list): A list of column names.

    Returns:
        dict: A dictionary with the specified structure.
    """
    # target is delta table and source is load DF
    dict = {}
    for col_name in col_list:
        dict[col_name] = f"{source_alias_keyword}.{col_name}"
    return dict


def generate_delete_condition_for_delta_in_raw(col_name, action_code, target_alias_keyword="target", source_alias_keyword="source"):
    delete_condition = f"{source_alias_keyword}.{col_name}" + " = " + f"'{action_code}'"


def generate_merge_condition_for_ssn_handling(target_key, source_key, target_alias_keyword="target", source_alias_keyword="source"):
    # target is delta table and source is load DF
    merge_condition = '{}.{} = {}.{}'.format(target_alias_keyword, target_key, source_alias_keyword, source_key)
    return merge_condition


def generate_update_condition_for_ssn_handling(target_alias_keyword="target", source_alias_keyword="source"):
    # target is delta table and source is load DF
    return {'participant_id': f"{source_alias_keyword}.new_participant_id"}


def generate_merge_condition_for_control_table(merge_keys, target_alias_keyword="target", source_alias_keyword="source"):
    # target is delta table and source is load DF
    merge_condition = ' and '.join('{}.{} = {}.{}'.format(target_alias_keyword, pkColumn, source_alias_keyword, pkColumn) for pkColumn in merge_keys)
    return merge_condition


def generate_update_condition_for_control_table(col_list, target_alias_keyword="target", source_alias_keyword="source"):
    # target is delta table and source is load DF
    dict = {}
    for col_name in col_list:
        dict[col_name] = f"{source_alias_keyword}.{col_name}"
    return dict


def generate_insert_condition_for_control_table(col_list, target_alias_keyword="target", source_alias_keyword="source"):
    # target is delta table and source is load DF
    dict = {}
    for col_name in col_list:
        dict[col_name] = f"{source_alias_keyword}.{col_name}"
    return dict