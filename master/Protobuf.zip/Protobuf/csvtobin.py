#!/usr/bin/env python3
import csv
import sys
sys.path.insert(1, '/home/ubuntu/demo/master/')
from protobuf.data.csv_pb2 import csvdata

with open("input.csv", "r") as f_input:
    csv_input = csv.DictReader(f_input)

    for row in csv_input:
        request_id = row['request_id']
        value = row['value']
        group = row['group']
        prop = row['prop']
        ypos = row['ypos']
        text = row['text']

        reqdata = csvdata (
            name = name,
            value = value,
            group = group,
            prop = prop,
            ypos = ypos,
            text = text)
        f = open("/home/ubuntu/demo/master/examples/proto_output.txt","wb")
        f.write(reqdata.SerializeToString())
        f.close()