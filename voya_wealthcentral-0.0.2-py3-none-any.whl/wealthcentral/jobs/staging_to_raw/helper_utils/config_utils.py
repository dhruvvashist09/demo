__author__ = "lumiq"
# config_utils.py: Contains utility functions for managing PySpark configuration settings
# such as loading configuration files and setting up environment variables.


from wealthcentral.utils.object_utils import StagingJobArguments
from wealthcentral.jobs.staging_to_raw.helper_utils.objects_utils import FileParameters


def read_file_parameters(config_file, source_name: str, file_name: str, file_segment_name: str):
    """
    Loop through each source in the source list and create a dictionary of
    dataset name and its dataframe.
    :param sources: List of sources
    :param spark: spark session
    :return: dictionary of key:dataset_name and value:dataframe
    """
    for source in config_file['source']:
        if source['sourceName'] == source_name and source['fileName'] == file_name:
            if source['primaryKeys']:
                primary_keys = source['primaryKeys']
            else:
                primary_keys = None
            return FileParameters(
                source_name=source_name,
                file_name=file_name,
                file_type=source['fileType'],
                file_format=source['fileFormat'],
                file_segmented_flag=source['fileSegmentedFlag'],
                file_load=source['fileLoad'],
                primary_keys=primary_keys,
                file_segment_name=file_segment_name,
                file_header_flag=source['headerPresentFlag']
            )
    return None
