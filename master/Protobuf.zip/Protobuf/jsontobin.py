#!/usr/bin/env python3
import json
import sys
sys.path.insert(1, '/home/ubuntu/demo/master/')
from protobuf.data.csv_pb2 import csvdata

with open("input.json", "r") as f_input:
    json_input = json.load(f_input)

    for row in json_input:
        request_id = json_input.get('request_id')
        corporation_site_id = int(json_input.get('corporation_site_id'))
        analysis_timeframe_start = json_input.get('analysis_timeframe_start')
        analysis_timeframe_end = json_input.get('analysis_timeframe_end')
        analysis_time_period = json_input.get('analysis_time_period')

        reqdata = csvdata (
            request_id = request_id,
            corporation_site_id = corporation_site_id,
            analysis_timeframe_start = analysis_timeframe_start,
            analysis_time_period = analysis_time_period)
        f = open("/home/ubuntu/demo/master/examples/proto_output.txt","wb")
        f.write(reqdata.SerializeToString())
        f.close()
