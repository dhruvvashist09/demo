__author__ = "lumiq"

from pyspark.sql import SparkSession
from delta.tables import DeltaTable


def init_spark_session():
    spark = SparkSession\
        .builder\
        .appName("Voya_WealthCentral") \
        .getOrCreate()
        #.config("spark.jars.packages", "io.delta:delta-core_2.12:0.8.0") \
        #.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        #.config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")\

    return spark


def create_database(spark, database_name):
    """
    Creates a new database in Databricks with the specified name.
    Parameters:
        database_name (str): The name of the database to create.
    Returns:
        None
    """
    # Check if the database already exists
    spark.sql(f"CREATE DATABASE IF NOT exists {database_name}")
    print(f"The '{database_name}' database has been created in catalog")


def overwrite_load(spark, df, database_name, table_name, partition_cols=None, location=None):
    """
    Writes a DataFrame to a table in a specified database and table.

    Parameters:
        spark (SparkSession): The SparkSession to use for the write operation.
        df (DataFrame): The DataFrame to write to the table.
        database_name (str): The name of the database to write the table to.
        table_name (str): The name of the table to write the DataFrame to.
        partition_cols (list): A list of column names to partition the data by (optional).
        location (str): The location to write the table data to (optional).

    Returns:
        None
    """
    # Create the database and table in the Delta Lake metastore
    create_database(
        spark=spark,
        database_name=database_name
    )

    # Write the DataFrame
    writer = df\
        .write\
        .format("parquet")\
        .option("path", f"{location}")\
        .option("partitionOverwriteMode", "dynamic")\
        .mode("overwrite")

    # Add partitioning if specified
    if partition_cols:
        writer = writer.partitionBy(*partition_cols)

    writer.saveAsTable(f"{database_name}.{table_name}")


def read_from_catalog(spark, database_name, table_name, condition_list=None, value_list=None):
    """
    Reads from a table in the Databricks catalog with optional conditions.
    Parameters:
        spark (SparkSession): The SparkSession object.
        database_name (str): The name of the database containing the table.
        table_name (str): The name of the table to read from.
        condition_list (list): A list of column names for the conditions.
        value_list (list): A list of values for the conditions. Can be a list of lists.

    Returns:
        DataFrame: The DataFrame containing the results of the query.
    """
    # Define the Spark SQL query template
    query_template = f"SELECT * FROM {database_name}.{table_name}"

    # Add conditions to the query if provided
    if condition_list and value_list:
        conditions = []
        for i, col_name in enumerate(condition_list):
            if isinstance(value_list[i], str):
                conditions.append(f"{col_name} = '{value_list[i]}'")
            elif isinstance(value_list[i], list):
                list_variables = ', '.join([f"'{value}'" for value in value_list[i]])
                conditions.append(f"{col_name} IN ({list_variables})")
        if conditions:
            query_template += f" WHERE {' AND '.join(conditions)}"

    print(query_template)

    # Read the table into a DataFrame
    df = spark.sql(query_template)

    return df



def merge_and_write_delta_load(spark, df, database_name, table_name, merge_condition=None, delete_condition=None, update_condition=None, insert_condition=None, location=None):
    """
    Handles inserts, updates, and deletes in a Delta table using the merge function.

    Parameters:
        df (DataFrame): The DataFrame to write to the Delta table.
        database_name (str): The name of the database that contains the Delta table.
        table_name (str): The name of the Delta table to write the DataFrame to.
        delta_location (str): The file system location of the Delta table.

    Returns:
        None
    """
    if location is not None:
        # Create the DeltaTable object, or create an empty Delta table if it doesn't exist
        try:
            delta_table = DeltaTable.forPath(spark, location)
        except:
            schema = df.schema
            DeltaTable.create(spark) \
                .tableName(f"{database_name}.{table_name}") \
                .location(location) \
                .addColumns(schema) \
                .execute()
            delta_table = DeltaTable.forPath(spark, location)
    else:
        delta_table = DeltaTable.forName(spark, '{}.{}'.format(database_name, table_name))

    # Merge the changes into the Delta table
    writer = delta_table.alias("target")

    if merge_condition:
        writer = writer.merge(df.alias("source"), merge_condition)

    if delete_condition:
        writer = writer.whenMatchedDelete(condition=delete_condition)

    if update_condition:
        writer = writer.whenMatchedUpdate(set=update_condition)

    if insert_condition:
        writer = writer.whenNotMatchedInsert(values=insert_condition)


    writer.execute()

    # Vacuum the Delta table
    delta_table.vacuum()


def read_delta_from_catalog(spark, database_name, table_name):
    return DeltaTable.forName(spark, '{}.{}'.format(database_name, table_name))
